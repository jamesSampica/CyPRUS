#!/bin/sh

SNV_VERSION=`git show -s --format=%H`
echo -n "Git-$SNV_VERSION"

