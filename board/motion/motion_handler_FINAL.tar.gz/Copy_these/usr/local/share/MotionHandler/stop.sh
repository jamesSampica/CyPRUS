#!/bin/bash

killall process_motion
killall motion
echo
